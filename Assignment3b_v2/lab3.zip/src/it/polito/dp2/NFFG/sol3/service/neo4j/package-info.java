@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/Neo4J", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package it.polito.dp2.NFFG.sol3.service.neo4j;
