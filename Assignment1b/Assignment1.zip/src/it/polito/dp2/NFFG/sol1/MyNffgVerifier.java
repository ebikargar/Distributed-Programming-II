package it.polito.dp2.NFFG.sol1;

import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import com.oracle.xmlns.internal.webservices.jaxws_databinding.ObjectFactory;

import it.polito.dp2.NFFG.NffgReader;
import it.polito.dp2.NFFG.NffgVerifier;
import it.polito.dp2.NFFG.NffgVerifierException;
import it.polito.dp2.NFFG.NodeReader;
import it.polito.dp2.NFFG.PolicyReader;
import it.polito.dp2.NFFG.ReachabilityPolicyReader;
import it.polito.dp2.NFFG.TraversalPolicyReader;
import it.polito.dp2.NFFG.sol1.jaxb.NffgType;
import it.polito.dp2.NFFG.sol1.jaxb.NffgVerifierType;
import it.polito.dp2.NFFG.sol1.jaxb.ReachabilityPolicyType;
import it.polito.dp2.NFFG.sol1.jaxb.TraversalPolicyType;

public class MyNffgVerifier implements NffgVerifier{

	// ------------ NffgVerifier Element --------------------------------//

	private Set<NffgReader> nffg_r_set;

	// ---------------------------------------------------------//

	public MyNffgVerifier() throws NffgVerifierException {

		nffg_r_set = new HashSet<NffgReader>();
		// policy_r_set = new HashSet<PolicyReader>();
		NffgVerifierType rootElement = null;

		for (NffgType nffg_t : rootElement.getNffg()) {

			NffgReader nffg_r = new MyNffgReader(nffg_t);
			nffg_r_set.add(nffg_r);

			List<ReachabilityPolicyType> reachability_policy_set = nffg_t.getPolicies().getReachabilityPolicy();
			for (ReachabilityPolicyType reachability_policy_t : reachability_policy_set) {
				ReachabilityPolicyReader reachability_policy_r = new MyReachablilityPolicyReader(nffg_t,
						reachability_policy_t);
				reachability_policy_set.add(reachability_policy_t);

			}
			List<TraversalPolicyType> traversal_policy_set = nffg_t.getPolicies().getTraversalPolicy();
			for (TraversalPolicyType traversal_policy_t : traversal_policy_set) {
				TraversalPolicyReader traversal_policy_r = new MyTraversalPolicyReader(nffg_t, traversal_policy_t);
				traversal_policy_set.add(traversal_policy_t);

			}

		}

	}

	// ----------------------------------------------------------------------//

	@Override
	public NffgReader getNffg(String arg0) {
		for (NffgReader nffg_r : nffg_r_set) {
			if (nffg_r.equals(arg0)) {
				return nffg_r;
			}
		}
		return null;
	}

	@Override
	public Set<NffgReader> getNffgs() {
		if(nffg_r_set!=null)		
		return nffg_r_set;
		else{
			System.out.println("nffg_r_set Object is Null");
			return null;
		}
	}

	@Override
	public Set<PolicyReader> getPolicies() {
		if (policy_r_set != null)
			return policy_r_set;
		else {
			System.out.println("Policy reader set object is Null");
			return null;
		}
	}

	@Override
	public Set<PolicyReader> getPolicies(String arg0) {
		
		for (PolicyReader policy_r : policy_r_set) {
			if (policy_r.equals(arg0)) {
				return policy_r;
			}
			return null;
	}

	@Override
	public Set<PolicyReader> getPolicies(Calendar arg0) {
		return null;
	}

}
